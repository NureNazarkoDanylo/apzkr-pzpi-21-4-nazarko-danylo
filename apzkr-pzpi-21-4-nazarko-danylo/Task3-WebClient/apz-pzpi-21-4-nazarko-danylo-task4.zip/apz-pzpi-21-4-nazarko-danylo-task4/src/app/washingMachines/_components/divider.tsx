import styles from '../_styles/divider.module.css'

export default function Divider() {
  return <div className={styles.divider} />
}
