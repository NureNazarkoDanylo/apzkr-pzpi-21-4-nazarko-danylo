
export default function SignUp() {
  return <h1>Hello, Signup Page!</h1>;
}
