namespace WashingMachineManagementIot.Models;

public enum State
{
    Idle,
    Prewash,
    Washing,
    Rinsing,
    Spinning
}
