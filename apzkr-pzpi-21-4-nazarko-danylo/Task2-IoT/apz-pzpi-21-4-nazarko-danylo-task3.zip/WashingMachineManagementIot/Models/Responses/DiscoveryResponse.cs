namespace WashingMachineManagementIot.Models.Responses;

public class DiscoveryResponse
{
    public string Id { get; set; }

    public string Manufacturer { get; set; }

    public string SerialNumber { get; set; }

    public string Name { get; set; }
}
