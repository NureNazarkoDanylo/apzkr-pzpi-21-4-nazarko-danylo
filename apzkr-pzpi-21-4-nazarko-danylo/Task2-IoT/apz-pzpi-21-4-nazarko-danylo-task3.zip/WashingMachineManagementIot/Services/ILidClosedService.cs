namespace WashingMachineManagementIot.Services;

public interface ILidClosedService
{
    public bool GetIsLidCloed();
}
