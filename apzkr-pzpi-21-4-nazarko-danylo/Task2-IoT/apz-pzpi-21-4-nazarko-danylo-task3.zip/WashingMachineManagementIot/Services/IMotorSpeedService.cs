namespace WashingMachineManagementIot.Services;

public interface IMotorSpeedService
{
    public int GetMotorSpeedInRpm();
}
