namespace WashingMachineManagementIot.Services;

public interface ILoadWeightService
{
    public double GetLoadWeightInKg();
}
