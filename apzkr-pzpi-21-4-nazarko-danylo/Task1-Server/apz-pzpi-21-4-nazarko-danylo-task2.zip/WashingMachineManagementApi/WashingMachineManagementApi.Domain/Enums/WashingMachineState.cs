public enum WashingMachineState
{
    Idle,
    Prewash,
    Washing,
    Rinsing,
    Spinning
}
