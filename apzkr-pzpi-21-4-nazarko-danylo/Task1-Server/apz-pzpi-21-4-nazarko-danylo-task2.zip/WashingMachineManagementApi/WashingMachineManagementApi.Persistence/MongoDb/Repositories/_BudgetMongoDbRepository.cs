// using WashingMachineManagementApi.Application.Common.IRepositories;
// using WashingMachineManagementApi.Domain.Entities;
//
// namespace WashingMachineManagementApi.Persistence.MongoDb.Repositories;
//
// public class BudgetMongoDbRepository : BaseMongoDbRepository<Budget, string>, IBudgetRepository
// {
//     public BudgetMongoDbRepository(MongoDbContext mongoDbContext)
//         : base(mongoDbContext, "budgets") { }
// }
