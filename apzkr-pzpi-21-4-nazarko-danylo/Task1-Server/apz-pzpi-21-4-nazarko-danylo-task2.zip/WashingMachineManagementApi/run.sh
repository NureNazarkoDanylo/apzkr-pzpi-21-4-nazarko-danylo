#!/usr/bin/env sh

dotnet run --project WashingMachineManagementApi.Api --environment Development
