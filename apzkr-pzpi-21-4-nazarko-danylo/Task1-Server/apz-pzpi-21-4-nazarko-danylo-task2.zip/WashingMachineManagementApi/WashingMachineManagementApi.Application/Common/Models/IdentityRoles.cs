namespace WashingMachineManagementApi.Application.Common.Models;

public enum IdentityRoles
{
    User = 0,
    Administrator = 1
}
